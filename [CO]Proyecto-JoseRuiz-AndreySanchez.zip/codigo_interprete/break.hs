<?hh
funcion muestra_break():entero{
    $iteraciones = 0;
    mientras($iteraciones < 50){
        si($iteraciones < 10){
            $iteraciones =  $iteraciones + 1;
        }sino{
            $iteraciones =  $iteraciones + 10;
        detener;
        }
        imprimir $iteraciones;
    } 
    retornar $iteraciones;
}



muestra_break();
