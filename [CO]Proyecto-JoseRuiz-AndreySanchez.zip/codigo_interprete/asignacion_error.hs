<?hh

funcion funcion_asignacion():entero{
		$varString = "hola_" + "pepe";

		$varNum1 = 20;
		$varNum2 = 10;

		$varBooleana = 3<10;

		$newVariable = $varNum1 + $varBooleana;

		imprimir $newVariable;
        retornar $newVariable; 
}



funcion_asignacion();
