<?hh



funcion sumatoria_f():entero{
		$sumatoria = 0;
        para($i = 0; $i < 100 ;$i = $i + 1){
            $sumatoria = $sumatoria + $i;
        }
        imprimir $sumatoria;
        retornar $i;
        
}



sumatoria_f();
