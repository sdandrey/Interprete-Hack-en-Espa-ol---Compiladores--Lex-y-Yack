<?hh



funcion do_while($num):entero{
		$res = 0
		hacer{
			$res = $res + 1;
		}
		mientras(10<$num);

		imprimir $res;



        retornar $res;
}



do_while(5);
