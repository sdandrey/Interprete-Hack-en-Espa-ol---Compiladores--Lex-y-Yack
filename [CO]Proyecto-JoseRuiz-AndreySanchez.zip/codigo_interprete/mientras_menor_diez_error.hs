<?hh



funcion muestra_while():entero{
    $iteraciones = 0;
    ,
    mientras($iteraciones < 50){
        si($iteraciones < 10){
            $iteraciones =  $iteraciones + 1;
        }sino{
            $iteraciones =  $iteraciones + 10;
        }
        imprimir $iteraciones;
    } 
    retornar $iteraciones;
}



muestra_while();