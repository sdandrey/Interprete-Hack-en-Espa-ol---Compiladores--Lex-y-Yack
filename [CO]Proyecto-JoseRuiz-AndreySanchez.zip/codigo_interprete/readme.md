no vamos a tener async,
name no lleva name-nondigit U+007f–U+00ff,
reemplazar NAME_NONDIGIT por NONDIGIT