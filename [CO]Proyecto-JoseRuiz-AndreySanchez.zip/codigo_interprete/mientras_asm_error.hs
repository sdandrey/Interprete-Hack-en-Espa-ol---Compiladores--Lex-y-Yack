<?hh



funcion muestra_while($iteraciones):entero{
    mientras(($iteraciones < 50){
        imprimir $iteraciones;
        $iteraciones = $iteraciones + 5;
    } 
    retornar $iteraciones;
}



muestra_while(12);