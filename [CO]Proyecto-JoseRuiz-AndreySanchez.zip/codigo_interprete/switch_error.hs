<?hh



funcion muestra_switch($valor):entero{
	res = 0;

	cambiar($valor){
		caso 1{
			$res = 0;
		}
		caso 2{
			$res = 1;
			detener;
		}
		caso 3{
			$res = 2;
			detener;
		}
		caso 2{
			$res = 3;
		}
		pordefecto{
			$res = 4;
		}
	}


	imprimir $res;
    retornar $res;
}



muestra_switch(23);