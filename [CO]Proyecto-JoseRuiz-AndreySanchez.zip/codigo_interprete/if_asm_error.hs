<?hh



funcion asm_if():entero{
		.
		$jose = 1921;
		$p = 3;
		$varX= 44444;
		si(verdadero y verdadero){
			imprimir $varX;
		}sino{
			imprimir $jose;
		}
        retornar $varX; 
}



asm_if();
