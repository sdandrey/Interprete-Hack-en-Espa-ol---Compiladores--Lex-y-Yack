package compilador;

public class Do_While extends Expression{

	Expression booleanExpression; //Condition
	Expression exp1;
	
	public Do_While(Expression b, Expression e1){
		booleanExpression = b;
		exp1 = e1;
		
	}
	
	public String toString(){
		return "do_while(" + booleanExpression + ") {" + exp1 + "}"; 
	}
	
	public synchronized int interpret() {
		int contador = 0;
		exp1.interpret();
		while(booleanExpression.interpret() == 1){
			exp1.interpret();
		}
		
		return 1;
	}

	@Override
	public int getType() {
		return -1;
	}

	@Override
	public Expression clone() {
		return new Do_While(booleanExpression.clone(), exp1.clone());
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

}