package compilador;

public class Continue extends Expression{

	@Override
	public int interpret() {
		return 0;
	}

	@Override
	public int getType() {
		return 7;
	}

	@Override
	public Expression clone() {
		return new Continue();
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

}
