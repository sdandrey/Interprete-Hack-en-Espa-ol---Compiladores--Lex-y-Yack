package compilador;

public class Return extends Expression{
	Expression exp1;
	
	public Return(Expression pExp1){
		exp1 = pExp1;
	}
	
	public int interpret() {
		return exp1.interpret();
	}

	@Override
	public int getType() {
		return 5; // 5 - return
	}

	@Override
	public Expression clone() {
		return new Return(exp1.clone());
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

}
