package compilador;

public class Level {
	public int number;
	public Expression exp;
	
	public Level(int pNumber, Expression pExp){
		number = pNumber;
		exp = pExp;
	}
	

}
