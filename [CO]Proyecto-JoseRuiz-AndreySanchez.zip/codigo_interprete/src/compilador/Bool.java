package compilador;

public class Bool extends Expression{
	boolean b; //value
	
	public Bool(String s){
		try{
			b = Boolean.parseBoolean(s);
		}catch(Exception e){
			System.err.println("Error, no se puede convertir a boolean: " + e.getMessage().toString());
		}
	}
	
	
	public String toString(){
		return b+"";
	}
	public synchronized int interpret(){
		if(b){
			return 1;
		}
		return -1;
	}


	@Override
	public int getType() {
		return 1; //Boolean
	}


	@Override
	public Expression clone() {
		return new Bool(b+"");
	}


	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
