package compilador;

public abstract class Expression implements Cloneable {
	public int indicador = 0;
	public abstract int interpret();
	public abstract int getType();// 0 - Numbers, 1 - Booleans, 4 Switch, 5 - Return, 6 - Break, 7 - Continue, 10 - Strings
	public abstract Expression clone();
	public abstract String getName();
	

}
