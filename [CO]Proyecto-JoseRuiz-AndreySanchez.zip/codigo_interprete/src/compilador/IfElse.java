package compilador;

public class IfElse extends Expression{

	
	Expression booleanExpression; //Condition
	Expression exp1, exp2; //Statements of if and else
	
	public IfElse(Expression b, Expression e1, Expression e2){
		booleanExpression = b;
		exp1 = e1;
		exp2 = e2;
		
	}
	
	public String toString(){
		return "if" + booleanExpression +"{ " + exp1 + "} else{"+ exp2 +"}";
	}
	
	
	
	public synchronized int interpret() {
		int b = booleanExpression.interpret();
		if(b==1){
			if(exp1.interpret()==100){
				return 100;
			}
			return 1;
		}else{
			if(exp2.interpret()==100){
				return 100;
			}
		}
		return -1;
	}

	@Override
	public int getType() {
		return -1;
	}

	@Override
	public Expression clone() {
		return new IfElse(booleanExpression.clone(),exp1.clone(),exp2.clone());
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

}
