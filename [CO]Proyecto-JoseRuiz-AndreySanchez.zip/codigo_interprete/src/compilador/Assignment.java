package compilador;

public class Assignment extends Expression {
	String name;
	Expression value;
	public Assignment(String pName, Expression pValue){
		name = pName;
		value = pValue;
	}
	
	public void setName(String pName){
		name = pName;
	}
	public String getName(){
		return name;
	}
	
	public String toString(){
		return name + " = " + value.toString();
	}

	@Override
	public synchronized int interpret() {
		try{
			if(value.getType() == 1 ) {
				Sintactico.tabla.insertar(name, value.interpret(),1);
				
			}
			if(value.getType() == 0) {
				Sintactico.tabla.insertar(name, value.interpret(),0);
			}
			if(value.getType() == 10) {
				Sintactico.tabla.insertar(name, value.getName(),10);
			}
			
			if(value.getType() == -1){
				System.err.println("Error de asignacion en variable: "+ name + ", Tipos no compatibles");
				System.exit(1);
			}
			
			return 1;
		}catch(Exception e){
			System.err.println("Error en asignacion: " + value.toString());
			System.err.println(e.getMessage());
			System.exit(1);
			return -1;
		}
		
	}

	@Override
	public int getType() {
		return value.getType();
	}

	@Override
	public Expression clone() {
		Assignment temp = new Assignment(getName(), value.clone());
		return temp;
	}

}
