
package compilador;

public class ForExp extends Expression{
	Expression initial;
	Expression booleanExpression; //Condition
	Expression exp1; //Control opt
	Expression exp2; //Body of "For"
	
	public ForExp(Expression ini,Expression b, Expression e1, Expression e2){
		initial = ini;
		booleanExpression = b;
		exp1 = e1;
		exp2 = e2;
		
	}
	
	public String toString(){
		return "For(Inicializador; " + booleanExpression + "; "+ exp1+") {" + exp2 + "}"; 
	}
	
	public synchronized int interpret() {
		int indicador = 0;
		initial.interpret();
		while(booleanExpression.interpret() == 1){
			indicador = exp2.interpret();
			if(indicador==100){
				break;
			}
			if(indicador==200){
				//System.out.println("Hay un continue dentro del for");;
			}
			
			exp1.interpret(); // Es la expresion de control
		}
		return 1;
	}

	@Override
	public int getType() {
		return -1;
	}

	@Override
	public Expression clone() {
		return new ForExp(initial.clone(),booleanExpression.clone() ,exp1.clone(),exp2.clone());
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

}
