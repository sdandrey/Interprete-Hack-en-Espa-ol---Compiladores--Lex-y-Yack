package compilador;

public class ConsultTable extends Expression{
	String name;
	
	public ConsultTable(String pName){
		name = pName;
	}
	
	public synchronized int interpret() {
		try{
			int a = Sintactico.tabla.buscar(name).getValue();
		}catch(Exception e){
			System.err.println("Error al obtener la variable: "+ name);
			System.exit(1);
		}
		return Sintactico.tabla.buscar(name).getValue();
		
	}
	
	public String toString(){
		if(Sintactico.tabla.buscar(name) == null){
			System.err.println("Error: La variable: " + name +" no existe");
			System.exit(1);
		}
		return name + Sintactico.tabla.buscar(name);
	}

	@Override
	public int getType() {
		return Sintactico.tabla.buscar(name).type ;
	}

	@Override
	public Expression clone() {
		return new ConsultTable(name);
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
