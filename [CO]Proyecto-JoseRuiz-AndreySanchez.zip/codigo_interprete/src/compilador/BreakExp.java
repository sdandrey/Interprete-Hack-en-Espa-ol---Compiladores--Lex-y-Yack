package compilador;

public class BreakExp extends Expression{

	@Override
	public int interpret() {
		return 0;
	}

	@Override
	public int getType() {
		return 6;
	}

	@Override
	public Expression clone() {
		return new BreakExp();
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

}
