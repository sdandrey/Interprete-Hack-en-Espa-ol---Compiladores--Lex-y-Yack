package compilador;

public class StringExp extends Expression{
	
	Expression exp1, exp2;
	char op;
	public StringExp(Expression e1, Expression e2, char opp){
		exp1 = e1;
		exp2 = e2;
		op = opp;
		
	}
	@Override
	public int interpret() {
		
		return 0;
	}

	@Override
	public int getType() {
		// TODO Auto-generated method stub
		return 10;
	}

	@Override
	public Expression clone() {
		// TODO Auto-generated method stub
		return new StringExp(exp1,exp2,op);
	}

	@Override
	public String getName() {
		String temp="";
		
		if(exp1.getType()!=10){
			System.err.println("Error: "+exp1.toString()+" no puede ser considerado un String");
			System.exit(1);
		}
		if(exp2.getType()!=10){
			System.err.println("Error: "+exp2.toString()+" no puede ser considerado un String");
			System.exit(1);
		}
		
		if(op=='+'){
			temp = exp1.getName() + exp2.getName();
		}
		return temp;
	}
	

}
