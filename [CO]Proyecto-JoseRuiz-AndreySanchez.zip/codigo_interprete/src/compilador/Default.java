package compilador;

public class Default extends Expression{
	Expression exp1;
	
	public Default(Expression ex){
		exp1 = ex;
		indicador = 1;
	}
	@Override
	public int interpret() {
		exp1.interpret();
		return 0;
	}

	@Override
	public int getType() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public Expression clone() {
		// TODO Auto-generated method stub
		return new Default(exp1);
	}
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

}
