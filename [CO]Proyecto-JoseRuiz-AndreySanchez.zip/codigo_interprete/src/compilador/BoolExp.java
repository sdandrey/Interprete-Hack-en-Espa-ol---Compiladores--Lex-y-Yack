package compilador;

public class BoolExp extends Expression{ // 1 true, 0 false
	Expression exp1, exp2;
	String kind;					// "==", "<" ... y, o
	
	public BoolExp(Expression e1, Expression e2, String k){
		exp1 = e1;
		exp2 = e2;
		kind = k;
	}
	public String toString(){
		return exp1 + (kind+"") + exp2;
	}
	
	public int conv(boolean b){
		if(b){
			return 1;
		}
		return 0;
	}
	
	
	public synchronized int interpret(){
		boolean temp1, temp2;
		
		if( (exp1.getType() == 1 && exp2.getType() == 1) || (exp1.getType() == 0 && exp2.getType() == 0) ){
		switch(kind){
		case "==": return conv(exp1.interpret() == exp2.interpret());
		case "<": return conv(exp1.interpret()<exp2.interpret());
		case ">": return conv(exp1.interpret()>exp2.interpret());
		case "o": 
					if(exp1.interpret()==1){
						temp1 = true;
					}else{
						temp1 = false;
					}
					if(exp2.interpret()==1){
						temp2 = true;
					}else{
						temp2 = false;
					}
					return conv(temp1 || temp2);
					
		case "y": 
					if(exp1.interpret()==1){
						temp1 = true;
					}else{
						temp1 = false;
					}
					if(exp2.interpret()==1){
						temp2 = true;
					}else{
						temp2 = false;
					}
					return conv(temp1 && temp2);
					
		}
		}else{
			System.err.println("Los tipos son diferentes");
		}
		return -1; 
	}
	@Override
	public int getType() {
		return 1; //Indica que es booleano
	}
	@Override
	public Expression clone() {
		return new BoolExp(exp1.clone(),exp2.clone(),kind);
	}
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}
}
