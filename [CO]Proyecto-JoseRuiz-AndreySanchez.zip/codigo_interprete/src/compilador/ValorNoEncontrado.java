package compilador;


public class ValorNoEncontrado extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	ValorNoEncontrado(String pNombre){
		super("Error: El valor "+pNombre+" no se ha encontrado.");
	}
}