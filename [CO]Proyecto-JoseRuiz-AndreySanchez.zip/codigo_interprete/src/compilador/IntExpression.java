package compilador;

public class IntExpression extends Expression {
	Expression e1,e2;
	char op;
	
	public IntExpression(Expression p1, Expression p2, char k){
		e1 = p1;
		e2 = p2;
		op = k;
	}
	
	public String toString(){
		return e1.toString() + " "+op+" "+e2.toString();
	}
	
	@Override
	public synchronized int interpret() {
		if( (e1.getType()==0 && e2.getType() == 0 )){
		
		switch (op){
		case '+': return( e1.interpret() + e2.interpret() );
		case '-': return( e1.interpret() - e2.interpret() );
		case '*': return( e1.interpret() * e2.interpret() );
		case '/': return( e1.interpret() / e2.interpret() );

		
		}
		
		}else{
			System.err.println("No se puede realizar una operacion entre diferentes tipos");
			System.exit(1);
			
		}

		return -1; //error
	}

	@Override
	public int getType() {
		if(e1.getType() == 0 && e2.getType() == 0){
			return 0; //Num
		}
		return -1; //Error
	}

	@Override
	public Expression clone() {
		return new IntExpression(e1.clone(),e2.clone(),op);
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
