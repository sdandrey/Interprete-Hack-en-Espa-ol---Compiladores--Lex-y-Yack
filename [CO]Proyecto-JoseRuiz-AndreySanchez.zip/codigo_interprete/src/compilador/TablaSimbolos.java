package compilador;

import java.util.*;
public class TablaSimbolos {
	HashMap t;
	public TablaSimbolos(){
		t = new HashMap();
	}
	public int insertar(String nombre, int valor, int type){
		Simbolo s = new Simbolo(nombre, valor+"", type);
		t.put(nombre, s);
		return valor;
	}
	
	public int insertar(String nombre, String valor, int type){
		Simbolo s = new Simbolo(nombre, valor, type);
		t.put(nombre, s);
		return -2; //Para indicar que es un String
	}
	
	public Simbolo buscar(String nombre){
		Simbolo temp = (Simbolo)t.get(nombre);
		/*if(t.containsKey(nombre)==false){
			System.err.println("No existe la variable: "+ nombre);
			System.exit(1);
		}*/
		return temp;
	}
	public void modificarValor(String name, int value, int type){
		Simbolo temp = new Simbolo(name, value+"", type);
		t.remove(name);
		t.put(name, temp);
	}
	
	
	public void imprimir(){
		System.out.println();
		System.out.println("---Tabla de simbolos---");
		System.out.println();
		String tipoTemporal = "";
		Iterator it = t.values().iterator();
		String valor = "";
		while(it.hasNext()){
			Simbolo s = (Simbolo)it.next();
			tipoTemporal = "Desconocido";
			try{
				if(s.type == 0){
					tipoTemporal = "entero";
					valor = ""+s.value;
					
				}
				if(s.type == 1){
					if(Integer.parseInt(s.value) == -1){
						valor = "falso";
					}else{
						valor = "verdadero";
					}
					tipoTemporal = "Booleano";
				}
				if(s.type == 10){
					tipoTemporal = "String";
					valor = s.value;
				}
			System.out.println("Variable: "+s.name + "   Valor: "+valor + "   Tipo:  "+tipoTemporal);
			}catch(Exception e){
				System.err.println("Existe un simbolo nulo");
			}
		}
	}
}
