package compilador;

import java.util.ArrayList;

public class ListExpression extends Expression{
	public ArrayList<Expression> expList;
	int tipo = -1;
	
	public ListExpression(){
		expList = new ArrayList<Expression>();
	}
	
	public void add(Expression e){
		expList.add(e);
	}
	
	public String toString(){
		String res = "";
		for(int i = 0;i<expList.size();i++){
			res = res + expList.get(i).toString() +"\n";
		}
		return res;
	}
	
	public void limpiar(){
		expList.clear();
	}
	
	public Expression clone(){
		ListExpression temp = new ListExpression();
		for(int i = 0;i<expList.size();i++){
			temp.add((Expression)expList.get(i).clone());
		}
		return temp;
	}
	

	public synchronized int interpret(){
		int indicador = 0;
		for(int i = 0;i<expList.size();i++){
			try{
				indicador = expList.get(i).interpret();
				if(expList.get(i).getType()==6){
					return 100; //Indica que hay un break
				}
				if(indicador==100){
					return 100; //Indica que hay un break
				}
				
				if(expList.get(i).getType()==7){
					return 200; //Indica que hay un continue
				}
				if(indicador==200){
					return 200; //Indica que hay un continue
				}
				
				//expList.get(i).interpret();
			}catch(Exception e){
				System.err.println("");
			};
		}
		
		return 1; //Se retorna 100 para indicar que es un break, 200 para indicar que es un continue
	}

	@Override
	public int getType() {
		for(int i = expList.size()-1 ;i>=0;i--){
			try{
				if(expList.get(i).getType() == 5){
					tipo = 5;			// function's indicate
				}
			}catch(Exception e){
				System.err.println("");
				
			};
		}
		return tipo;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}
}
