package compilador;

public class Number extends Expression{
	int n; //value
	ConsultTable ex;
	
	public Number(String s){
		try{
			n = Integer.parseInt(s);
		}catch(Exception e){
			System.err.println("error, no se puede convertir a numero " + e.getMessage().toString());
		}
		ex = null;
	}
	public Number(ConsultTable ex){
		n = 0;
		this.ex = ex;
	}
	
	public Number(int pN){
		n = pN;
	}
	
	public String toString(){
		return n+"";
	}
	public synchronized int interpret(){
		if(ex==null){
			return n;
		}
		return ex.interpret();
		
	}
	@Override
	public int getType() {
		return 0;
	}
	@Override
	public Expression clone() {
		return new Number(n);
	}
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}
}
