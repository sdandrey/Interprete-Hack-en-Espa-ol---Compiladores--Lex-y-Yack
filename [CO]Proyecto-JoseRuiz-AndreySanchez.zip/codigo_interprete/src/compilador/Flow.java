package compilador;

import java.util.ArrayList;

public class Flow{
	
	public static ArrayList<ListExpression> listTemp = new ArrayList<ListExpression>();
	public static int currentIndex = 0;
	public static int max = 0;
	
	
	public static void ini(){
		listTemp.add(new ListExpression()); listTemp.add(new ListExpression());
		currentIndex++;
		
		if(currentIndex>max){
			max = currentIndex;
		}
	}
	public static void add(Expression e1){
		listTemp.get(currentIndex).add(e1.clone());
	}
	
	public static Expression get() throws CloneNotSupportedException{
		ListExpression temp = (ListExpression)listTemp.get(currentIndex--).clone();
		listTemp.get(currentIndex+1).limpiar();
		return (Expression)temp;
	}


}
