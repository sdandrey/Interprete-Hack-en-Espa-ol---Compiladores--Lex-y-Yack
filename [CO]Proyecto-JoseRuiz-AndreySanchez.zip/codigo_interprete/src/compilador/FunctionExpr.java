package compilador;

import java.util.ArrayList;

public class FunctionExpr extends Expression{
	public String name;
	ArrayList parameterList;
	ArrayList valuesList;
	Expression e1;
	
	
	public FunctionExpr(String pName, ArrayList parameters){
		name = pName;
		parameterList = parameters;
	}
	
	public void setStatements(Expression e){
		e1 = e;
	}
	
	public void setValuesList(ArrayList e){
		valuesList = e;
	}

	@Override
	public int interpret() {
		if(e1.getType() != 5){
			System.err.println("No existe retornar en la funcion");
			return -1;
		}
		if(valuesList.size()!=parameterList.size()){
			System.err.println("Verifique que exista la misma cantidad de parametros y de valores al llamar la funcion");
			System.exit(1);
		}
		
		for(int i = 0;i<valuesList.size();i++){
			new Assignment(parameterList.get(i).toString(), new Number((int)valuesList.get(i))).interpret();
		}
		e1.interpret();
		return 0;
	}

	@Override
	public int getType() {
		return 2;
	}

	@Override
	public Expression clone() {
		FunctionExpr temp = new FunctionExpr(name, (ArrayList)parameterList.clone());
		temp.setStatements(e1.clone());
		temp.setValuesList((ArrayList)valuesList.clone());
		return temp;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

}
