package compilador;

public class Case extends Expression{
	Expression num;
	Expression exp1;
	
	public Case(Expression n, Expression pExp1){
		num = n;
		exp1 = pExp1;
	}
	
	public String toString(){
		return "caso: " + num + " Statement: "+exp1.toString();
	}
	
	
	@Override
	public int interpret() {
		return exp1.interpret();
	}

	@Override
	public int getType() {
		return num.interpret();
	}

	@Override
	public Expression clone() {
		return new Case(num.clone(),exp1.clone());
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

}
