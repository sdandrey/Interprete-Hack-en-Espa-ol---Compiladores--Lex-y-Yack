package compilador;

public class Imprimir extends Expression{
	Expression exp1;
	
	public Imprimir(Expression pExp1){
		exp1 = pExp1;
	}
	
	public int interpret() {
		System.out.println(exp1.interpret());
		return 1;
	}

	@Override
	public int getType() {
		return -1; // 5 - return
	}

	@Override
	public Expression clone() {
		return new Imprimir(exp1);
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

}
