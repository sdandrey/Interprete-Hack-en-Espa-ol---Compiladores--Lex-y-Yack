/**
 * 
 */
package compilador;
import java.io.FileInputStream;



/**
 * @author jose
 *
 */

public class Compilador {
    /**
	     * @param args the command line arguments
	     */
		TablaSimbolos tabla = new TablaSimbolos();
	    public static void main(String[] args) throws Exception {
	        System.out.println("-------------------------------");
	        boolean showTokens = false;
	        boolean showSymbols = false;
	        boolean showAsm = false;
	        
	        String filename = "";
	        try{
	        	filename = args[0];
	        }catch(Exception e){
	        	System.err.println("Error: Debe de ingresar el nombre de un archivo");
	        	System.exit(1);
	        }
	        
	        for(int i = 1;i<args.length;i++){
	        	switch(args[i]){
	        	
	        	case "-t":
	        		showTokens = true;
	        		System.out.println("Se mostrara los tokens");
	        		break;
	        	case "-a":
	        		showAsm = true;
	        		System.out.println("Se mostrara el codigo asm");
	        		break;
	        	case "-s":
	        		showSymbols = true;
	        		System.out.println("Se mostrara la tabla de simbolos");
	        		break;
	        	default:
	        		System.err.println("Parametro no valido: " + args[i].toString());
	        		System.exit(1);
	        	}
	        }
	        
	        Sintactico t = new Sintactico(new Scanner(new FileInputStream(filename),showTokens));
	        t.parse();
	        if(showSymbols){
	        	t.mostrarSimbolos();
	        }
	        if(showAsm){
	        	t.mostrarAsm();
	        }
	        
	        

	    }
	}
