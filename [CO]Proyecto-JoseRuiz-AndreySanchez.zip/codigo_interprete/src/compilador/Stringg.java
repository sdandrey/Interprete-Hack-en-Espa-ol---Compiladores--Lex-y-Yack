package compilador;

public class Stringg extends Expression {
	String value;
	
	public Stringg(String pValue){
		value = pValue;
		
	}
	@Override
	public synchronized int interpret() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public int getType() {
		return 10; //Hace referencia a que es un string
	}
	@Override
	public Expression clone() {
		return new Stringg(value);
	}
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return value;
	}

}
