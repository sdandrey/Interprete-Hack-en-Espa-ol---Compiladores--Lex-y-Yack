package compilador;

public class Simbolo {
	String name;
	String value;
	int type;
	
	public Simbolo(String pName, String pValue, int pType){
		name = pName;
		value = pValue;
		type = pType;
	}

	public String toString(){
		return "Nombre: "+name+" valor: "+value;
	}
	public int getValue() {
		return Integer.parseInt(value);

	}
}
