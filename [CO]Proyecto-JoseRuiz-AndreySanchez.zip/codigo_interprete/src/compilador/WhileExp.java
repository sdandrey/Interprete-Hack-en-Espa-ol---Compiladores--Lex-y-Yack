package compilador;

public class WhileExp extends Expression{

	Expression booleanExpression; //Condition
	Expression exp1;
	
	public WhileExp(Expression b, Expression e1){
		booleanExpression = b;
		exp1 = e1;
		
	}
	
	public String toString(){
		return "while(" + booleanExpression + ") {" + exp1 + "}"; 
	}
	
	public synchronized int interpret() {
		int contador = 0;
		int indicador = 0;
		while(booleanExpression.interpret() == 1){
			indicador = exp1.interpret();
			if(indicador==100){
				break;
			}
			if(indicador == 200){
				//Se puede indicar que hay un continue dentro del while
			}
		}
		
		return 1;
	}

	@Override
	public int getType() {
		return -1;
	}

	@Override
	public Expression clone() {
		return new WhileExp(booleanExpression.clone(),exp1.clone());
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

}
