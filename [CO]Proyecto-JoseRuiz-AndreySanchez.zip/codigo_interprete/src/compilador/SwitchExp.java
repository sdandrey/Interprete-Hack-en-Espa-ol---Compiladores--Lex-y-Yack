package compilador;

import java.util.ArrayList;

public class SwitchExp extends Expression{
	Expression n;
	ArrayList<Expression> listExpression;
	
	public SwitchExp(Expression n1, Expression ex){
		listExpression = ((ListExpression)ex).expList;
		n = n1;
	}
	
	public SwitchExp(Expression n1, ArrayList<Expression> ex){
		listExpression = ex;
		n = n1;
	}
	

	@Override
	public int interpret() {
		int num = 0;
		try{
		num = n.interpret();
		}catch(Exception e){
			System.err.println("Error en switch: " + e.getMessage());
		}
		
		for(int i = 0;i<listExpression.size();i++){
			if(num==listExpression.get(i).getType()){
				if(listExpression.get(i).interpret()==100){
					break;
				}
			}
		}
		
		return 0;
	}

	@Override
	public int getType() {
		// TODO Auto-generated method stub
		return 4;
	}

	@Override
	public Expression clone() {
		return new SwitchExp(n.clone(), (ArrayList<Expression>)listExpression.clone());
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

}
