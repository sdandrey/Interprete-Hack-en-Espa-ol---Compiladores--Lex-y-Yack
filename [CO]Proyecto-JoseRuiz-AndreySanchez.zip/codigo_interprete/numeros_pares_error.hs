<?hh



funcion num_pares():entero{
        para($i = 0; $i < 100 ;$i = $i + 2){
            imprimir $i;
        }
        retornar $i;
        
}



num_paress();
