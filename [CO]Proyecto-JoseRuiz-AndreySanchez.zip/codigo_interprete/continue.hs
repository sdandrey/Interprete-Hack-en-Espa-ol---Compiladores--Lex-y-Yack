<?hh



funcion muestra_continue():entero{
	$q = 0;
	$u = 0;
	para($i = 0;$i<100;$i = $i + 1){
		si(10<$i){
			$q = $q + 10;
			continuar;
			$u = $u + 1;
		}
		sino{
			$u = $u + 20;
		}
	}
	imprimir $q;
	imprimir $u;
    retornar $q;
}



muestra_continue();