<?hh



funcion for_asm():entero{
		$cadena_de_strings = "string";
        for($numero_del_para = 30; $numero_del_para<32;$numero_del_para = $numero_del_para + 1){
            imprimir $numero_del_para+2;
        }
        retornar $numero_del_para;
}



for_asm();
